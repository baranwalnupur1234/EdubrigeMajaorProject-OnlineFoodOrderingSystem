package database.com.connection.file;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import admin.food.items.com.food;



public class FoodItemsDAO {

//	food_id int (24)  NOT NULL AUTO_INCREMENT,
//	food_name varchar(220),
//	food_type varchar(220),
//	price



	

	public static int save(food f){
		int status=0;
		try{
			Connection con = DBConnection.init();
			PreparedStatement ps=con.prepareStatement("insert into  FoodItems(food_name,food_type,price) values(?,?,?)");
			ps.setString(1,f.getFood_name());
			ps.setString(2,f.getFood_type());
			ps.setString(3,f.getPrice());
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int update(food f){
		int status=0;
		try{
			Connection con = DBConnection.init();
			PreparedStatement ps=con.prepareStatement("update FoodItems set food_name=?,food_type=?,price=? where food_id=?");
		
			ps.setString(1,f.getFood_name());
			ps.setString(2,f.getFood_type());
			ps.setString(3,f.getPrice());
			ps.setInt(4,f.getFood_id ());
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int delete(food f){
		int status=0;
		try{
			Connection con = DBConnection.init();
			PreparedStatement ps=con.prepareStatement("delete from FoodItems where food_id=?");
			ps.setInt(1,f.getFood_id());
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}

		return status;
	}
	public static List<food> getAllRecords(){
		List<food> list=new ArrayList<food>();
		
		try{
			Connection con = DBConnection.init();
			PreparedStatement ps=con.prepareStatement("select * from FoodItems");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				food f=new food();
				f.setFood_id(rs.getInt("food_id"));
				f.setFood_name(rs.getString("food_name"));
				f.setFood_type(rs.getString("food_type"));
				f.setPrice(rs.getString("price"));
				list.add(f);
			}
		}catch(Exception e
				){System.out.println(e);
		}
		return list;
	}
	public static food getRecordByFood_id(int food_id){
		food f=null;
		try{
			Connection con = DBConnection.init();
			PreparedStatement ps=con.prepareStatement("select * from FoodItems where food_id=?");
			ps.setInt(1,food_id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				f=new food();
				f.setFood_id(rs.getInt("food_id"));
				f.setFood_name(rs.getString("food_name"));
				f.setFood_type(rs.getString("food_type"));
				f.setPrice(rs.getString("price"));
			}
		}catch(Exception e){System.out.println(e);}
		return f;
	}
	}





